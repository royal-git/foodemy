package company.com.volve.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentTransaction;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

import company.com.volve.Activities.EventManager;
import company.com.volve.R;

public class ChooseSocNavigationFragment extends android.support.v4.app.Fragment {

    static SimpleAdapter simpleAdapter;
    private static String Society_ID = "ID";
    private static String Society_Name = "Name";
    private static ArrayList<HashMap<String, String>> societyList;
    EditText inputSearch;
    int ids[] = {R.drawable.icon72, R.drawable.icon72, R.drawable.icon72, R.drawable.icon72, R.drawable.icon72};

    //getSocieties gSocs = new getSocieties();
    public ChooseSocNavigationFragment() {
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_choose_soc_navigation, container, false);
        //getList of events.
        societyList = EventManager.getSocietyList();
        System.out.println("Making Societies!");
        ListView mListView = view.findViewById(R.id.listView_contacts);
        inputSearch = view.findViewById(R.id.inputSearch);

        ArrayList<HashMap<String, String>> societies = new ArrayList<>();
        for (int i = 0; i < societyList.size(); i++) {

            HashMap<String, String> hashMap = new HashMap<>();
            System.out.println(Society_Name + " : " + societyList.get(i).get(Society_Name) + " with a size of: " + societyList.size());
            hashMap.put("name", societyList.get(i).get(Society_Name));
            hashMap.put("image", ids[i % 3] + "");
            final String currentID = societyList.get(i).get(Society_ID);
            System.out.println("SOCIETY ID: " + currentID);
            societies.add(hashMap);
            String keys[] = {"name", "image"};

            int id[] = {R.id.textView_contact, R.id.imageView_contact};


            simpleAdapter = new SimpleAdapter(getContext(), societies, R.layout.template_contact, keys, id);
            mListView.setAdapter(simpleAdapter);
            mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    System.out.println();
                    String item = parent.getItemAtPosition(position).toString().replace("{", "").replace("}", "");
                    String[] itemz = item.split(",")[1].split("=");
                    System.out.println("Clicked Item: " + getSocID(itemz[1]) + " - " + itemz[1]);
                    InsideSocFragment g = new InsideSocFragment();
                    g.getMessage(getSocID(itemz[1]));

                    assert getFragmentManager() != null;
                    FragmentTransaction transaction = getFragmentManager().beginTransaction();

                    transaction.replace(R.id.screen_area, g);
                    transaction.addToBackStack(null);
                    transaction.commit();
                }
            });

            inputSearch.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    simpleAdapter.getFilter().filter(charSequence);

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    simpleAdapter.getFilter().filter(charSequence);

                }

                @Override
                public void afterTextChanged(Editable editable) {

                }
            });


        }
        return view;
    }

    private String getSocID(String title) {
        for (int i = 0; i < societyList.size(); i++) {
            HashMap<String, String> event = societyList.get(i);
            if (event.get(Society_Name).equalsIgnoreCase(title)) {
                return event.get(Society_ID);
            }
        }
        return "-1";
    }
}
