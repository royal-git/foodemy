package company.com.volve.Fragments;


import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.json.JSONArray;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;

import company.com.volve.Activities.EventManager;
import company.com.volve.R;

import static company.com.volve.R.string.locationReplace;

/**
 * A simple {@link Fragment} subclass.
 */
@SuppressWarnings("ALL")
public class SocTabFragment extends Fragment {
    // event
    private static final String TAG_EVENTS = "data";
    private static final String TAG_WHAT = "name";
    private static final String TAG_WHEN = "start_time";
    private static final String TAG_TIMEZONE = "timezone";
    // place
    private static final String TAG_WHERE = "place";
    private static final String TAG_WHERE_NAME = "name";
    private static final String TAG_WHERE_LOCATION = "location";
    private static final String TAG_WHERE_LOCATION_CITY = "city";
    private static final String TAG_WHERE_LOCATION_COUNTRY = "country";
    private static final String TAG_WHERE_LOCATION_STATE = "state";
    private static final String TAG_WHERE_LOCATION_STREET = "street";
    private static final String TAG_WHERE_LOCATION_ZIP = "zip";
    private static final String TAG_DESCRIPTION = "description";
    private static final String TAG_TYPE = "type";
    final String TAG = "EventsTabFragment.java";
    ListView lv;
    int year_range = 2; // get events for the next x years
    // events JSONArray
    JSONArray events = null;
    // Hashmap for ListView
    ArrayList<HashMap<String, String>> eventList;
    private ProgressDialog progressDialog;

    public SocTabFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_events_tab, container, false);

        // get since date
        SimpleDateFormat sdfDateTime = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        String since_date = sdfDateTime.format(new Date(System.currentTimeMillis()));

        String since_unix_timestamp = getTimeStamp(since_date);

        // get until date
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(sdfDateTime.parse(since_date));
        } catch (ParseException e) {
            e.getStackTrace();
        }
        c.add(Calendar.YEAR, year_range);

        Date result_date = new Date(c.getTimeInMillis());
        String until_date = sdfDateTime.format(result_date);

        String until_unix_timestamp = getTimeStamp(until_date);

        eventList = new ArrayList<HashMap<String, String>>();
        eventList = EventManager.getFilteredList("1"); //1 == event type 1
        /*
            Event description is returned when a user clicks on a specific event.
            lv when clicked gets the description of that event.
        */
        lv = view.findViewById(R.id.list);

        // Listview on item click listener
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String description = ((TextView) view.findViewById(R.id.description)).getText().toString();
                String what = ((TextView) view.findViewById(R.id.what)).getText().toString();
                String when = ((TextView) view.findViewById(R.id.when)).getText().toString().replaceAll(String.valueOf(R.string.dateTimeReplace), "");
                final String where = ((TextView) view.findViewById(R.id.where)).getText().toString().replaceAll(String.valueOf(R.string.locationReplace), "");;
//                Toast.makeText(getContext(), where, Toast.LENGTH_LONG).show();

                new AlertDialog.Builder(view.getContext())
                        .setTitle(description)
                        .setMessage(R.string.dateSlashTime + when +
                                R.string.newlineVenue + where)
                        .setPositiveButton(R.string.closeBtn, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();

                            }
                        })
                        .setNegativeButton("Navigate to Venue", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                Uri uriUrl = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + where.replaceAll("Location:", ""));
                                startActivity(new Intent(Intent.ACTION_VIEW, uriUrl));

                            }
                        }).show();
            }
        });

        // update parsed data into ListView
        try {
            ListAdapter adapter = new SimpleAdapter(
                    getContext(),
                    eventList,
                    R.layout.list_item,
                    new String[]{
                            TAG_WHAT,
                            TAG_WHEN,
                            TAG_WHERE,
                            TAG_DESCRIPTION
                    },
                    new int[]{
                            R.id.what,
                            R.id.when,
                            R.id.where,
                            R.id.description
                    }
            );

            lv.setAdapter(adapter);
        } catch (Exception e) {
            Log.e("rotationEvent", "Crash avoided with catch block");
        }
        return view;
    }


    // get formatted 'when' field
    public String getWhen(String dateInput, String timeZone) {

        String dateOutput = "";

        try {

            DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ssZ");

            DateFormat df2 = new SimpleDateFormat("cccc, MMMM d, yyyy hh:mm a");
            df2.setTimeZone(TimeZone.getTimeZone(timeZone));

            dateOutput = df2.format(df1.parse(dateInput));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return dateOutput;
    }

    // get unix timestamp
    public String getTimeStamp(String ymd) {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

        Date date = null;

        try {
            date = (Date) formatter.parse(ymd);
        } catch (ParseException e) {
            e.getStackTrace();
        }

        long output = date.getTime() / 1000L;
        String str = Long.toString(output);
        long timestamp_result = Long.parseLong(str);

        return Long.toString(timestamp_result);
    }

}
