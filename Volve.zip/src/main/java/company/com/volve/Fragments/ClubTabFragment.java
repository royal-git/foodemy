package company.com.volve.Fragments;


import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;

import company.com.volve.Activities.ServiceHandler;
import company.com.volve.R;

import static company.com.volve.Activities.LoadingScreen.myRef;

/**
 * A simple {@link Fragment} subclass.
 */
@SuppressWarnings("ALL")
public class ClubTabFragment extends Fragment {
    // event
    private static final String TAG_EVENTS = "data";
    private static final String TAG_WHAT = "name";
    private static final String TAG_WHEN = "start_time";
    private static final String TAG_TIMEZONE = "timezone";
    // place
    private static final String TAG_WHERE = "place";
    private static final String TAG_WHERE_NAME = "name";
    private static final String TAG_WHERE_LOCATION = "location";
    private static final String TAG_WHERE_LOCATION_CITY = "city";
    private static final String TAG_WHERE_LOCATION_COUNTRY = "country";
    private static final String TAG_WHERE_LOCATION_STATE = "state";
    private static final String TAG_WHERE_LOCATION_STREET = "street";
    private static final String TAG_WHERE_LOCATION_ZIP = "zip";
    private static final String TAG_DESCRIPTION = "description";
    private static final String TAG_TYPE = "type";
    // url to get json data
    final String TAG = "EventsTabFragment.java";
    ListView lv;
    int year_range = 2; // get events for the next x years
    // events JSONArray
    JSONArray events = null;
    // Hashmap for ListView
    ArrayList<HashMap<String, String>> eventList;
    private ProgressDialog progressDialog;

    public ClubTabFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_events_tab, container, false);

        // get since date
        SimpleDateFormat sdfDateTime = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        String since_date = sdfDateTime.format(new Date(System.currentTimeMillis()));

        String since_unix_timestamp = getTimeStamp(since_date);

        // get until date
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(sdfDateTime.parse(since_date));
        } catch (ParseException e) {
            e.getStackTrace();
        }
        c.add(Calendar.YEAR, year_range);

        Date result_date = new Date(c.getTimeInMillis());
        String until_date = sdfDateTime.format(result_date);

        String until_unix_timestamp = getTimeStamp(until_date);

        eventList = new ArrayList<HashMap<String, String>>();
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (int i = 0; i < dataSnapshot.getChildrenCount(); i++) {
                    //each node is dataSnapshot..child(Integer.toString(i));
                    String description = dataSnapshot.child(Integer.toString(i)).child("description").getValue().toString().replace("DESCRIPTION: ", "");
                    String name = dataSnapshot.child(Integer.toString(i)).child("name").getValue().toString().replace("WHAT: ", "");
                    String place = dataSnapshot.child(Integer.toString(i)).child("place").getValue().toString().replace("WHERE: ", "");
                    String when = dataSnapshot.child(Integer.toString(i)).child("start_time").getValue().toString().replace("WHEN: ", "");
                    String  eventType = dataSnapshot.child(Integer.toString(i)).child("groupType").getValue().toString();
                    HashMap<String, String> event = new HashMap<String, String>();

                    if (eventType.equals("1")) {
                        // adding each child node to HashMap key => value
                        event.put(TAG_WHAT, name);
                        event.put(TAG_WHEN, "Date/Time: " + when);
                        event.put(TAG_TYPE, eventType);
                        event.put(TAG_WHERE, "Location: " + place);
                        event.put(TAG_DESCRIPTION, description);

                        // adding event to event list
                        eventList.add(event);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
        /*
            Event description is returned when a user clicks on a specific event.
            lv when clicked gets the description of that event.
        */
        lv = view.findViewById(R.id.list);

        // Listview on item click listener
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String description = ((TextView) view.findViewById(R.id.description)).getText().toString();
                String what = ((TextView) view.findViewById(R.id.what)).getText().toString();
                String when = ((TextView) view.findViewById(R.id.when)).getText().toString().replaceAll("Date/Time:", "");
                final String where = ((TextView) view.findViewById(R.id.where)).getText().toString().replaceAll("Location:", "");;
//                Toast.makeText(getContext(), where, Toast.LENGTH_LONG).show();

                new AlertDialog.Builder(view.getContext())
                        .setTitle(description)
                        .setMessage("Date/Time: " + when +
                                "\nVenue:" + where)
                        .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();

                            }
                        })
                        .setNegativeButton("Navigate to Venue", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                Uri uriUrl = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + where.replaceAll("Location:", ""));
                                startActivity(new Intent(Intent.ACTION_VIEW, uriUrl));

                            }
                        }).show();
            }
        });

        // Calling async task to get json
        new GetEvents().execute();
        return view;
    }


    // get formatted 'when' field
    public String getWhen(String dateInput, String timeZone) {

        String dateOutput = "";

        try {

            DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ssZ");

            DateFormat df2 = new SimpleDateFormat("cccc, MMMM d, yyyy hh:mm a");
            df2.setTimeZone(TimeZone.getTimeZone(timeZone));

            dateOutput = df2.format(df1.parse(dateInput));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return dateOutput;
    }

    // get unix timestamp
    public String getTimeStamp(String ymd) {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

        Date date = null;

        try {
            date = (Date) formatter.parse(ymd);
        } catch (ParseException e) {
            e.getStackTrace();
        }

        long output = date.getTime() / 1000L;
        String str = Long.toString(output);
        long timestamp_result = Long.parseLong(str);

        return Long.toString(timestamp_result);
    }

    // Async task class to get json by making HTTP call
    private class GetEvents extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0) {

            // instance of service handler class
            ServiceHandler sh = new ServiceHandler();

            // make request to url, jsonStr will store the response
            String jsonStr = sh.makeServiceCall("http://blank.org", ServiceHandler.GET);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

                    // get json array node

                    events = jsonObj.getJSONArray(TAG_EVENTS);

                    // looping through all facebook events
                    for (int i = 0; i < events.length(); i++) {

                        JSONObject c = events.getJSONObject(i);

                        String what = c.getString(TAG_WHAT);
                        String when = c.getString(TAG_WHEN);
                        String timezone = c.getString(TAG_TIMEZONE);
                        String eventType = c.getString(TAG_TYPE);
                        // place node is JSON Object
                        JSONObject where = c.getJSONObject(TAG_WHERE);
                        String where_name = where.getString(TAG_WHERE_NAME);

                        JSONObject where_location = where.getJSONObject(TAG_WHERE_LOCATION);
                        String where_location_city = where_location.getString(TAG_WHERE_LOCATION_CITY);
                        String where_location_country = where_location.getString(TAG_WHERE_LOCATION_COUNTRY);
                        String where_location_state = where_location.getString(TAG_WHERE_LOCATION_STATE);
                        String where_location_street = where_location.getString(TAG_WHERE_LOCATION_STREET);
                        String where_location_zip = where_location.getString(TAG_WHERE_LOCATION_ZIP);

                        String where_complete = where_name + ", ";
                        where_complete += where_location_street.length() > 0 ? where_location_street + ", " : "";
                        where_complete += where_location_city.length() > 0 ? where_location_city + ", " : "";
                        where_complete += where_location_state.length() > 0 ? where_location_state + ", " : "";
                        where_complete += where_location_country.length() > 0 ? where_location_country + ", " : "";
                        where_complete += where_location_zip.length() > 0 ? where_location_zip : "";

                        String description = c.getString(TAG_DESCRIPTION);

                        // tmp hashmap for single event
                        HashMap<String, String> event = new HashMap<String, String>();

                        // adding each child node to HashMap key => value
                        event.put(TAG_WHAT, "WHAT: " + what);
                        event.put(TAG_WHEN, "WHEN: " + getWhen(when, timezone));
                        event.put(TAG_WHERE, "WHERE: " + where_complete);
                        event.put(TAG_DESCRIPTION, "DESCRIPTION: " + description);

                        // adding event to event list
                        eventList.add(event);
                    }

                    myRef.setValue(eventList);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            // update parsed data into ListView
            try {
                ListAdapter adapter = new SimpleAdapter(
                        getContext(),
                        eventList,
                        R.layout.list_item,
                        new String[]{
                                TAG_WHAT,
                                TAG_WHEN,
                                TAG_WHERE,
                                TAG_DESCRIPTION
                        },
                        new int[]{
                                R.id.what,
                                R.id.when,
                                R.id.where,
                                R.id.description
                        }
                );

                lv.setAdapter(adapter);
            } catch (Exception e) {
                Log.e("rotationEvent", "Crash avoided with catch block");
            }
        }
    }


}
