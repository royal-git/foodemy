package company.com.volve.Activities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import company.com.volve.R;

public class LoadingScreen extends Activity {

    TextView mTextView;
    static public FirebaseDatabase database = FirebaseDatabase.getInstance();
    public static DatabaseReference myRef = database.getReference("event");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        startHeavyProcessing();

        mTextView = findViewById(R.id.text_loadingScreen);

    }

    private void startHeavyProcessing() {
        new LongOperation().execute("");
    }
    @SuppressLint("StaticFieldLeak")
    private class LongOperation extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            for (int i = 0; i < 5000; i++) { //keep the limit here high to make as many polls as possible
                try {
                    Thread.sleep(1); //keep this value low to poll as often as possible
                } catch (InterruptedException e) {
                    Thread.interrupted();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            Intent mainIntent = new Intent(LoadingScreen.this, MainOpeningScreen.class);
            startActivity(mainIntent);
            finish();
        }

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }
}