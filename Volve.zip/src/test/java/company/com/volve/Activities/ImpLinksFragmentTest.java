package company.com.volve.Activities;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by tejaswinikumar on 20/03/18.
 */
public class ImpLinksFragmentTest {
    @Test
    public void goToSocieties() throws Exception {
    }

}